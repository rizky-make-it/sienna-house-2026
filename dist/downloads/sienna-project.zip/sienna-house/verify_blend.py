"""Non-mutating audit of the saved deliverable, for Blender --background."""
import bpy,json
from pathlib import Path
scene=bpy.context.scene;base=Path(__file__).resolve().parent
roots=[o for o in scene.objects if o.get('kind')=='product']
parts=[o for o in scene.objects if o.get('kind')=='articulation']
images=[i for i in bpy.data.images if i.source=='FILE' and i.users]
assert len(set(o.get('product_id') for o in roots))==14
assert len(roots)==17
assert len(parts)==32
assert all(image.packed_file for image in images)
assert (scene.render.resolution_x,scene.render.resolution_y)==(3840,2160)
assert len([o for o in scene.objects if o.type=='CAMERA'])==4
assert all(o.data.uv_layers for o in scene.objects if o.type=='MESH')
if scene.get('layout')=='exhibition':
    assert not any(o.get('kind') in {'wall','ceiling','windowglass','exterior'} for o in scene.objects)
    metadata=json.loads(scene['web_scene_info'])
    assert metadata['walls']==0 and metadata['roof'] is False
    assert metadata['floorBounds']==[-1.5,-1.2,13.5,11.8]
report={'ok':True,'products':14,'placements':len(roots),'articulations':len(parts),'objects':len(scene.objects),'meshes':sum(1 for o in scene.objects if o.type=='MESH'),'uv_complete':True,'packed_images':len(images),'units':scene.unit_settings.system,'unit_scale':scene.unit_settings.scale_length,'render_resolution':[scene.render.resolution_x,scene.render.resolution_y],'engine':scene.render.engine,'cameras':[o.name for o in scene.objects if o.type=='CAMERA']}
report.update({'layout':scene.get('layout','house'),'walls':sum(1 for o in scene.objects if o.get('kind')=='wall'),'roof':any(o.get('kind')=='ceiling' for o in scene.objects)})
(base/'blend-audit.json').write_text(json.dumps(report,indent=2));print('SIENNA_BLEND_VERIFIED',json.dumps(report),flush=True)
