"""SIENNA catalogue furniture, authored in metres for Blender.

The 2026 catalogue is the visual and dimensional source, not a manufacturer CAD
model. Visible construction is matched; concealed joinery is a plausible design
interpretation. Coordinates: X = frontage, Y = depth, front = -Y, Z = up.
Each product's root is at floor centre. Mirror origin is its lower-edge centre.

create(sku, instance=None) returns a product root. Articulation pivots have
``kind``, ``action``, ``distance`` / ``angle`` and ``product_id`` custom props.
Drawer travel is local -Y; cabinet door rotation is local Z.
"""

import math
import random
from contextlib import contextmanager

import bpy
import core as c


PRODUCTS = {
    'LV463-B01': ('Queen Bed', (1.630, 2.125, 1.200)),
    'LV463-B02': ('King Bed', (1.930, 2.125, 1.200)),
    'LV463-B42': ('2 Drawer & Shelf Bedside', (.550, .400, .550)),
    'LV463-B51': ('2 Over 4 Drawers Tallboy', (.900, .450, 1.200)),
    'LV463-B61': ('3 Over 4 Drawers Dresser', (1.500, .450, .800)),
    'LV463-B71': ('Mirror', (1.000, .026, 1.000)),
    'LV463-D01': ('8-seat Rectangle Dining Table', (2.200, 1.000, .760)),
    'LV463-L21': ('1 Drawer & Shelf Console', (1.400, .400, .760)),
    'LV463-D21': ('3 Drawers 4 Doors Buffet', (1.800, .450, .820)),
    'LV446-L01': ('Rectangle Coffee Table with Shelf', (1.200, .700, .440)),
    'LV446-L02': ('Square Coffee Table with Shelf', (.900, .900, .440)),
    'LV446-L11': ('1 Drawer & Shelf Lamp Table', (.550, .550, .550)),
    'LV446-L12': ('Sofa Table', (.460, .250, .500)),
    'LV446-L31': ('4 Doors & Shelf TV Unit', (1.800, .440, .550)),
}

_SERIAL = {}
_SKU = None
_STRIPE = None


@contextmanager
def parent(obj):
    previous = c.PARENT
    c.set_parent(obj)
    try:
        yield
    finally:
        c.set_parent(previous)


def b(name, loc, dims, mat='wood', bevel=.003, rot=None):
    return c.box(name, loc, dims, mat, bevel=bevel, rot=rot)


def uv_mesh(name, verts, faces, uvfaces, mat='wood', smooth=False):
    """Explicit loop UVs keep veneer grain independent of object transforms."""
    obj = c.mesh(name, verts, faces, mat, smooth=smooth)
    layer = obj.data.uv_layers.active or obj.data.uv_layers.new(name='UVMap')
    for polygon, coords in zip(obj.data.polygons, uvfaces):
        for loop_index, uv in zip(polygon.loop_indices, coords):
            layer.data[loop_index].uv = uv
    return obj


def veneer(name, x, y, z, w, h, chevron=True, phase=0.0):
    """Near-flush four-quadrant book-matched veneer; no artificial plank gaps.

    UV U follows the length of the timber grain. Four triangular sectors share
    the same plane but have alternating diagonal UV directions, recreating the
    diamond/chevron ash veneer visible in the supplied photographs.
    """
    if not chevron:
        verts = [(x-w/2, y, z-h/2), (x+w/2, y, z-h/2),
                 (x+w/2, y, z+h/2), (x-w/2, y, z+h/2)]
        return uv_mesh(name, verts, [(0, 1, 2, 3)],
                       [[(0+phase, 0), (w+phase, 0), (w+phase, h), (phase, h)]])
    corners = [(-w/2, -h/2), (w/2, -h/2), (w/2, h/2), (-w/2, h/2)]
    verts, faces, uvfaces = [], [], []
    # Each sector uses a grain direction that meets at the central diamond.
    for i, angle in enumerate((math.pi/4, -math.pi/4, math.pi/4, -math.pi/4)):
        triangle = [corners[i], corners[(i+1) % 4], (0, 0)]
        start = len(verts)
        verts.extend((x+u, y, z+v) for u, v in triangle)
        faces.append((start, start+1, start+2))
        co, si = math.cos(angle), math.sin(angle)
        uvfaces.append([(u*co+v*si+phase+(i % 2)*.37,
                         -u*si+v*co+.12*i) for u, v in triangle])
    return uv_mesh(name, verts, faces, uvfaces)


def face_panel(name, x, y, z, w, h, thickness=.018, chevron=True, phase=0):
    b(name+' substrate', (x, y+thickness/2, z), (w, thickness, h), 'wood', .002)
    veneer(name+' book-matched ash', x, y-.00035, z, w-.0014, h-.0014,
           chevron=chevron, phase=phase)


def handle(name, x, y, z, length=.125, vertical=False):
    """Slim rectangular brass bar with two perpendicular square stand-offs."""
    if vertical:
        for sign in (-1, 1):
            b(name+' mount', (x, y-.010, z+sign*(length/2-.012)),
              (.007, .022, .009), 'brass', .001)
        b(name+' bar', (x, y-.024, z), (.008, .010, length), 'brass', .0013)
    else:
        for sign in (-1, 1):
            b(name+' mount', (x+sign*(length/2-.012), y-.010, z),
              (.009, .022, .007), 'brass', .001)
        b(name+' bar', (x, y-.024, z), (length, .010, .008), 'brass', .0013)


def frame(name, w, d, h, bar=.016, bottom=.014, top=True, middle_x=None):
    """Catalogue signature: open, slender squared brass perimeter frame."""
    for sx in (-1, 1):
        for sy in (-1, 1):
            b(name+' upright', (sx*(w-bar)/2, sy*(d-bar)/2, h/2),
              (bar, bar, h), 'brass', .0015)
    for level in ([bottom, h-bar/2] if top else [bottom]):
        for sy in (-1, 1):
            b(name+' width rail', (0, sy*(d-bar)/2, level),
              (w, bar, bar), 'brass', .0013)
        for sx in (-1, 1):
            b(name+' depth rail', (sx*(w-bar)/2, 0, level),
              (bar, d, bar), 'brass', .0013)
    if middle_x is not None:
        for sy in (-1, 1):
            b(name+' centre upright', (middle_x, sy*(d-bar)/2, h/2),
              (bar, bar, h), 'brass', .001)


def carcass(name, w, d, low, high, divisions=(), shelf=None):
    """Real side/back/bottom/top boards leave an accessible hollow interior."""
    side = .018
    for sign in (-1, 1):
        b(name+' solid side', (sign*(w/2-.021), 0, (low+high)/2),
          (side, d-.026, high-low), 'wood', .0025)
        b(name+' inner side', (sign*(w/2-.031), 0, (low+high)/2),
          (.002, d-.045, high-low-.025), 'inside', .0005)
    b(name+' back panel', (0, d/2-.021, (low+high)/2),
      (w-.042, .012, high-low-.025), 'inside', .001)
    for z in (low+.009, high-.010):
        b(name+' horizontal board', (0, 0, z), (w-.022, d-.022, .018),
          'wood', .003)
    for x in divisions:
        b(name+' divider', (x, .005, (low+high)/2),
          (.018, d-.045, high-low-.025), 'inside', .0015)
    if shelf is not None:
        b(name+' internal shelf', (0, .005, shelf),
          (w-.065, d-.055, .016), 'inside', .0015)
    for z in (low, high):
        b(name+' front brass trim', (0, -d/2+.006, z),
          (w-.020, .010, .007), 'brass', .001)


def drawer(name, x, front_y, z, w, h, depth, chevron=True, phase=0):
    """Sliding hollow drawer with front, bottom, side walls and both runners."""
    root = c.empty(name+' sliding pivot', (x, front_y, z), props={
        'kind': 'articulation', 'action': 'drawer', 'product_id': _SKU,
        'distance': round(min(depth*.80, .34), 4), 'label': name,
        'closed_y': front_y,
    })
    with parent(root):
        face_panel(name+' front', 0, 0, 0, w, h, chevron=chevron, phase=phase)
        handle(name+' handle', 0, -.001, .008, min(.14, w*.35))
        inner_w, inner_h = w-.040, max(.045, h-.027)
        b(name+' bottom', (0, depth/2+.005, -h/2+.018),
          (inner_w, depth-.022, .009), 'inside', .001)
        for sign in (-1, 1):
            b(name+' drawer side', (sign*(w/2-.023), depth/2+.007, -.006),
              (.012, depth-.018, inner_h), 'inside', .0015)
            b(name+' sliding inner runner', (sign*(w/2-.014), depth/2+.008, -.017),
              (.004, depth-.050, .018), 'brass', .0006)
            # Small face end-grain / joinery plugs, visible only when open.
            for k in range(3):
                b(name+' joinery pin', (sign*(w/2-.016), .025, -h*.30+k*h*.25),
                  (.002, .014, .006), 'wood', .0003)
        b(name+' drawer rear', (0, depth-.006, -.004),
          (inner_w, .012, inner_h), 'inside', .0014)
    # Cabinet-fixed runners remain still when the drawer slides outward.
    for sign in (-1, 1):
        b(name+' fixed runner', (x+sign*(w/2-.010), front_y+depth/2, z-.020),
          (.004, depth-.045, .021), 'black', .0007)
    return root


def door(name, cx, front_y, z, w, h, left_hinge=True, phase=0):
    hx = cx-w/2 if left_hinge else cx+w/2
    dx = w/2 if left_hinge else -w/2
    # Left-hinged left leaves open toward -Y with a negative Z rotation.
    pivot = c.empty(name+' hinge pivot', (hx, front_y, z), props={
        'kind': 'articulation', 'action': 'door', 'product_id': _SKU,
        'angle': math.radians(-105 if left_hinge else 105), 'label': name,
    })
    with parent(pivot):
        face_panel(name+' door', dx, 0, 0, w, h, chevron=True, phase=phase)
        handle_x = dx + (w/2-.045 if left_hinge else -w/2+.045)
        handle(name+' handle', handle_x, -.002, h*.18, .125, vertical=True)
        for sz in (-1, 1):
            hz = sz*(h/2-.055)
            # Concealed hinge plates and cylinder, revealed on opening.
            b(name+' hinge mounting plate', (0, .030, hz),
              (.026, .035, .040), 'brass', .0015)
            c.cylinder(name+' hinge knuckle', (0, .014, hz), .005, .035, 'brass')
            b(name+' hinge arm', (dx*.13, .026, hz),
              (abs(dx)*.26+.015, .009, .013), 'brass', .0007)
    return pivot


def cabinet_bedside(w, d, h):
    frame('Bedside brass frame', w, d, h, bar=.014)
    low = .090
    carcass('Bedside', w, d, low, h-.009)
    available = h-.026-low
    for index in range(2):
        height = available/2-.006
        z = low+.008+height/2+index*(available/2)
        drawer('Bedside drawer '+str(index+1), 0, -d/2+.013, z,
               w-.034, height, d-.052, phase=index*.27)


def cabinet_tallboy(w, d, h):
    frame('Tallboy brass frame', w, d, h, bar=.016)
    low = .075
    carcass('Tallboy', w, d, low, h-.008)
    usable = h-.025-low
    for i in range(4):
        dh = usable/4-.007
        z = low+.008+dh/2+i*(usable/4)
        drawer('Tallboy visible drawer '+str(i+1), 0, -d/2+.012, z,
               w-.036, dh, d-.053, phase=.19*i)
    # The title is verbatim catalogue text, but its photograph has four faces.
    c.PARENT['catalogue_note'] = 'Catalogue title says 2 Over 4; four wide fronts follow photograph.'


def cabinet_dresser(w, d, h):
    frame('Dresser brass frame', w, d, h, bar=.016)
    low = .065
    carcass('Dresser', w, d, low, h-.008)
    upper_h = .140
    split = h-.024-upper_h
    b('Dresser lower central divider', (0, .005, (low+split)/2),
      (.018, d-.045, split-low-.016), 'inside', .0015)
    b('Dresser top drawer partition', (0, .005, split),
      (w-.048, d-.045, .014), 'inside', .0015)
    for i in range(3):
        dw = (w-.045)/3-.006
        x = -(w-.045)/2+(i+.5)*(w-.045)/3
        drawer('Dresser upper drawer '+str(i+1), x, -d/2+.013,
               split+upper_h/2, dw, upper_h-.006, d-.055,
               chevron=False, phase=i*.23)
    dh = (split-low-.010)/2-.006
    for row in range(2):
        for col in range(2):
            x = (-1 if col == 0 else 1)*(w-.046)/4
            z = low+.012+dh/2+row*(dh+.006)
            drawer('Dresser lower drawer '+str(row*2+col+1), x, -d/2+.013,
                   z, (w-.046)/2-.007, dh, d-.055, phase=.16*(row+col))


def cabinet_buffet(w, d, h):
    frame('Buffet brass frame', w, d, h, bar=.017)
    low, split = .067, h-.165
    carcass('Buffet', w, d, low, h-.009, shelf=(low+split)/2)
    b('Buffet lower central divider', (0, .005, (low+split)/2),
      (.018, d-.045, split-low-.016), 'inside', .0015)
    b('Buffet drawer partition shelf', (0, .004, split),
      (w-.047, d-.052, .016), 'inside', .002)
    for i in range(3):
        dw = (w-.047)/3-.006
        x = -(w-.047)/2+(i+.5)*(w-.047)/3
        drawer('Buffet upper drawer '+str(i+1), x, -d/2+.013,
               (split+h-.025)/2, dw, h-.029-split, d-.055,
               chevron=False, phase=.24*i)
    inner_w = w-.044
    dh = split-low-.015
    for i in range(4):
        dw = inner_w/4-.004
        x = -inner_w/2+(i+.5)*inner_w/4
        door('Buffet door '+str(i+1), x, -d/2+.013, low+.009+dh/2,
             dw, dh, left_hinge=(i % 2 == 0), phase=.19*(i//2))
    for sx in (-1, 1):
        b('Buffet lower-door centre brass trim', (sx*inner_w/4, -d/2+.015,
                                                low+dh/2),
          (.004, .010, dh), 'brass', .0007)


def cabinet_tv(w, d, h):
    frame('TV unit brass frame', w, d, h, bar=.015)
    low, door_top, shelf_z = .065, .390, .403
    carcass('TV unit', w, d, low, door_top, divisions=(0,), shelf=.235)
    # The upper open shelf remains genuinely open and spans the full unit.
    b('TV unit top board', (0, 0, h-.012), (w-.020, d-.020, .023), 'wood', .003)
    b('TV open shelf', (0, .003, shelf_z), (w-.025, d-.025, .018), 'wood', .002)
    for sx in (-1, 1):
        b('TV shelf centre upright', (0, sx*(d/2-.012), (shelf_z+h)/2),
          (.012, .012, h-shelf_z), 'brass', .001)
    inner_w = w-.040
    for i in range(4):
        dw = inner_w/4-.005
        x = -inner_w/2+(i+.5)*inner_w/4
        door('TV unit door '+str(i+1), x, -d/2+.011, (low+door_top)/2,
             dw, door_top-low-.012, left_hinge=(i % 2 == 0), phase=.21*(i//2))
    # Rear cable outlet is an actual opening: a dark trim ring, not a painted dot.
    cable = c.empty('TV shelf cable grommet', (0, d/2-.015, .460))
    with parent(cable):
        ring = []
        for i in range(33):
            t = i/32*2*math.pi
            ring.append((.020*math.cos(t), 0, .020*math.sin(t)))
        c.curve('Cable opening brass rim', ring, .002, 'brass', cyclic=True)


def coffee(w, d, h):
    frame('Coffee table brass frame', w, d, h, bar=.016, middle_x=0)
    b('Coffee table ash top', (0, 0, h-.012), (w-.014, d-.014, .022), 'wood', .003)
    for side, level in ((-1, .120), (1, .260)):
        sw = w/2-.018
        cx = side*w/4
        b('Staggered ash shelf', (cx, .003, level),
          (sw, d-.028, .018), 'wood', .0025)
        for sy in (-1, 1):
            b('Staggered shelf brass edge', (cx, sy*(d/2-.009), level-.008),
              (sw, .012, .012), 'brass', .001)


def console(w, d, h):
    frame('Console brass frame', w, d, h, bar=.015, middle_x=.150)
    b('Console ash top', (0, 0, h-.011), (w-.015, d-.015, .021), 'wood', .003)
    b('Console long low shelf', (0, .002, .222), (w-.026, d-.027, .018), 'wood', .0025)
    b('Console left staggered shelf', (-.250, .002, .419),
      (.870, d-.027, .018), 'wood', .0025)
    b('Console right upper shelf', (.250, .002, .590),
      (.870, d-.027, .018), 'wood', .0025)
    # Drawer suspended within the offset right-hand bay.
    dw, dh, cx, cz = .520, .154, .402, .500
    for sign in (-1, 1):
        b('Console drawer case side', (cx+sign*(dw/2+.008), .006, cz),
          (.015, d-.040, dh+.013), 'wood', .002)
    b('Console drawer case back', (cx, d/2-.021, cz),
      (dw+.020, .012, dh+.013), 'wood', .0015)
    drawer('Console offset drawer', cx, -d/2+.013, cz, dw, dh,
           d-.055, chevron=True, phase=.12)
    b('Console upper right back panel', (.603, d/2-.020, .670),
      (.160, .015, .150), 'wood', .002)
    for z in (.222, .419, .590):
        length = w-.025 if z == .222 else .870
        x = 0 if z == .222 else (-.250 if z == .419 else .250)
        for sy in (-1, 1):
            b('Console brass shelf lip', (x, sy*(d/2-.009), z-.006),
              (length, .012, .012), 'brass', .001)


def lamp_table(w, d, h):
    frame('Lamp table brass frame', w, d, h, bar=.015)
    low, high = .205, .397
    carcass('Lamp table drawer case', w, d, low, high)
    drawer('Lamp table single drawer', 0, -d/2+.013, (low+high)/2,
           w-.035, high-low-.014, d-.055, phase=.18)
    b('Lamp table upper ash top', (0, 0, h-.011),
      (w-.015, d-.015, .021), 'wood', .003)


def sofa_table(w, d, h):
    bar = .021
    b('C table floating ash top', (0, 0, h-.017), (w, d, .034), 'wood', .004)
    for sy in (-1, 1):
        b('C table brass vertical support', (-w/2+.031, sy*(d/2-.024), (h-.035)/2),
          (bar, bar, h-.035), 'brass', .0017)
        b('C table brass base side', (0, sy*(d/2-.014), .012),
          (w-.025, bar, bar), 'brass', .0015)
    for sx in (-1, 1):
        b('C table brass base crossbar', (sx*(w/2-.023), 0, .012),
          (bar, d-.028, bar), 'brass', .0015)
    b('C table brass top support', (-w/2+.031, 0, h-.037),
      (bar, d-.031, bar), 'brass', .0015)


def dining(w, d, h):
    b('Dining table continuous ash top', (0, 0, h-.015), (w, d, .030), 'wood', .0045)
    # Two parallel brass portal pedestals, open to preserve catalogue silhouette.
    for side in (-1, 1):
        x = side*.670
        for sy in (-1, 1):
            b('Dining pedestal square upright', (x, sy*.335, (h-.030)/2),
              (.036, .036, h-.030), 'brass', .002)
        for z in (.020, h-.050):
            b('Dining pedestal depth crossbar', (x, 0, z),
              (.036, .706, .036), 'brass', .0018)
        # Internal second slim rail gives the doubled depth visible in photo.
        b('Dining pedestal stabilizer', (x+.022*side, 0, .036),
          (.018, .610, .018), 'brass', .0014)
    b('Dining underside support', (0, 0, h-.040),
      (1.480, .050, .030), 'brass', .002)


def mirror(w, d, h):
    width = .074
    for sx in (-1, 1):
        b('Mirror ash side frame', (sx*(w-width)/2, 0, h/2),
          (width, d, h), 'wood', .0025)
    for sz in (-1, 1):
        b('Mirror ash top-bottom frame', (0, 0, (width/2 if sz < 0 else h-width/2)),
          (w-2*width, d, width), 'wood', .002)
    # Diagonal frame veneers meet cleanly around the mirror aperture.
    veneer('Mirror upper ash veneer', 0, -d/2-.0003, h-width/2,
           w-.004, width-.003, chevron=False, phase=.22)
    veneer('Mirror lower ash veneer', 0, -d/2-.0003, width/2,
           w-.004, width-.003, chevron=False, phase=.51)
    for sx in (-1, 1):
        veneer('Mirror side ash veneer', sx*(w-width)/2, -d/2-.0003,
               h/2, width-.003, h-2*width, chevron=False, phase=.31)
    opening = w-2*width
    b('Optical silver mirror', (0, -.009, h/2),
      (opening+.002, .002, h-2*width+.002), 'mirror', .0005)
    for sx in (-1, 1):
        for edge in (w/2-.002, opening/2+.002):
            b('Mirror fine brass vertical trim', (sx*edge, -d/2-.001, h/2),
              (.003, .003, h-.003 if edge > opening/2+.003 else opening+.006),
              'brass', .0005)
    for sz in (-1, 1):
        for offset in (.002, width-.002):
            b('Mirror fine brass horizontal trim', (0, -d/2-.001,
                                                    offset if sz < 0 else h-offset),
              (w-.002 if offset < .01 else opening+.006, .003, .003),
              'brass', .0005)


def stripe_material():
    global _STRIPE
    if _STRIPE is not None and _STRIPE.name in bpy.data.materials:
        return _STRIPE
    _STRIPE = c.M['cotton'].copy()
    _STRIPE.name = 'SIENNA white cotton satin stripe'
    if _STRIPE.use_nodes:
        bsdf = next((n for n in _STRIPE.node_tree.nodes
                     if n.type == 'BSDF_PRINCIPLED'), None)
        if bsdf:
            bsdf.inputs['Roughness'].default_value = .47
            # Near-white alternate weave; not a heavy grey printed stripe.
            bsdf.inputs['Base Color'].default_value = (.83, .825, .80, 1)
            if 'Sheen Weight' in bsdf.inputs:
                bsdf.inputs['Sheen Weight'].default_value = .28
    return _STRIPE


def cotton_mesh(name, verts, faces, uvfaces, striped=False, stripe_indices=None):
    obj = uv_mesh(name, verts, faces, uvfaces, 'cotton', smooth=True)
    if striped:
        obj.data.materials.append(stripe_material())
        for p, index in zip(obj.data.polygons, stripe_indices or []):
            p.material_index = index
    return obj


def pillow(name, loc, width=.64, depth=.43, height=.18, tilt=.75, spin=0, seed=0):
    """Closed, softly inflated sewn pillow with pinched edges and local pleats."""
    rng = random.Random(seed)
    nx, ny = 30, 22
    verts, faces, uvfaces, stripes = [], [], [], []
    for side in (1, -1):
        for j in range(ny+1):
            v = j/ny
            for i in range(nx+1):
                u = i/nx
                x = (u-.5)*width
                y = (v-.5)*depth
                edge = max(0, math.sin(math.pi*u)*math.sin(math.pi*v))
                puff = height*.5*edge**.38
                # Drawn-in seam causes genuine radial wrinkles at the corners.
                wrinkle = (.006*math.sin(u*58+v*17)*math.exp(-v*12)
                           +.005*math.sin(v*48-u*11)*math.exp(-u*13)
                           +.004*math.sin(v*53+u*8)*math.exp(-(1-u)*13))
                z = side*(.006+puff+wrinkle*edge**.25)
                x += .006*math.sin(v*13+seed)*math.sin(math.pi*u)
                y += .004*math.sin(u*16+seed)*math.sin(math.pi*v)
                verts.append((x, y, z))
    layer_size = (nx+1)*(ny+1)
    for layer in range(2):
        for j in range(ny):
            for i in range(nx):
                a = layer*layer_size+j*(nx+1)+i
                f = (a, a+1, a+nx+2, a+nx+1)
                if layer:
                    f = tuple(reversed(f))
                faces.append(f)
                uvfaces.append([(verts[k][0], verts[k][1]) for k in f])
                stripes.append((i//2) % 2)
    boundary = ([i for i in range(nx+1)]
                +[j*(nx+1)+nx for j in range(1, ny+1)]
                +[ny*(nx+1)+i for i in range(nx-1, -1, -1)]
                +[j*(nx+1) for j in range(ny-1, 0, -1)])
    for k, a in enumerate(boundary):
        bb = boundary[(k+1) % len(boundary)]
        f = (a, a+layer_size, bb+layer_size, bb)
        faces.append(f)
        uvfaces.append([(0, 0), (0, .012), (.02, .012), (.02, 0)])
        stripes.append(0)
    root = c.empty(name+' placement', loc)
    root.rotation_euler = (tilt, .025*math.sin(seed), spin)
    with parent(root):
        obj = cotton_mesh(name+' inflated cotton', verts, faces, uvfaces,
                          striped=True, stripe_indices=stripes)
        seam = [(verts[k][0], verts[k][1], 0) for k in boundary]
        c.curve(name+' sewn piped edge', seam, .00125, 'stitch', cyclic=True)
        # A second finely separated seam is visible at close viewing distances.
        inset = [(x*.984, y*.976, .006) for x, y, _ in seam]
        c.curve(name+' folded seam', inset, .00055, 'cotton', cyclic=True)
    return root


def duvet(width, length=1.59, seed=12):
    """Dense draped quilt surface with broad weight folds and local wrinkles.

    Geometry, not a flat plane or texture, provides the silhouette and folds.
    Density stays bounded for efficient export: 11,616 vertices per duvet.
    """
    nx, ny = 120, 95
    half = width/2-.016
    verts, faces, uvfaces, stripes = [], [], [], []
    rng = random.Random(seed)
    creases = [(rng.uniform(-.80, .80), rng.uniform(.02, .55),
                rng.uniform(-.8, .8), rng.uniform(.010, .026),
                rng.uniform(.032, .075)) for _ in range(16)]
    for j in range(ny+1):
        v = j/ny
        yy = -1.043+length*v
        for i in range(nx+1):
            u = i/nx*2-1
            x = half*math.sin(u*math.pi/2)
            # Smoothly turns from horizontal bedding into hanging side fabric.
            fall = .235*abs(u)**10
            foot_fall = .135*math.exp(-v*23)
            base = .625-fall-foot_fall
            z = base + .009*math.sin(x*7+v*9)*math.sin(math.pi*v)
            z += .007*math.sin(x*13-v*8+.7)*(.3+.7*abs(u)**3)
            for centre, along, angle, amplitude, sigma in creases:
                delta = x-centre-angle*(v-along)
                # Crease ridges taper longitudinally instead of repeating waves.
                z += amplitude*math.exp(-(delta/sigma)**2
                                         -((v-along)/.23)**2)
            z += .009*math.sin(v*48+u*6)*abs(u)**7
            y = yy+.014*math.sin(u*11+v*3)*(.22+.78*(1-v)**5)
            verts.append((x, y, z))
    for j in range(ny):
        for i in range(nx):
            a = j*(nx+1)+i
            f = (a, a+1, a+nx+2, a+nx+1)
            faces.append(f)
            # UV follows pre-drape cloth coordinates, preventing stretched weave.
            uvfaces.append([(i/nx*width, j/ny*length),
                            ((i+1)/nx*width, j/ny*length),
                            ((i+1)/nx*width, (j+1)/ny*length),
                            (i/nx*width, (j+1)/ny*length)])
            stripes.append((i//2) % 2)
    obj = cotton_mesh('Sculpted striped white duvet', verts, faces, uvfaces,
                      striped=True, stripe_indices=stripes)
    # Real thickness at the exposed hem, not an expensive full subdivision mesh.
    boundary = ([i for i in range(nx+1)]
                +[j*(nx+1)+nx for j in range(1, ny+1)]
                +[ny*(nx+1)+i for i in range(nx-1, -1, -1)]
                +[j*(nx+1) for j in range(ny-1, 0, -1)])
    hem = [verts[i] for i in boundary]
    c.curve('Duvet thick sewn hem', hem, .0024, 'cotton', cyclic=True)
    c.curve('Duvet fine edge stitching',
            [(x*.997, y, z+.002) for x, y, z in hem], .0006, 'stitch', cyclic=True)
    # The folded-back top edge is a separate softly rolled strip of fabric.
    rollverts, rollfaces, rolluv = [], [], []
    for j in range(9):
        t = j/8
        for i in range(nx+1):
            u = i/nx*2-1
            x = half*.975*math.sin(u*math.pi/2)
            y = .490+.105*t+.014*math.sin(u*9)
            z = .633+.019*math.sin(t*math.pi)-.19*abs(u)**10
            z += .005*math.sin(x*18+t*3)
            rollverts.append((x, y, z))
    for j in range(8):
        for i in range(nx):
            a = j*(nx+1)+i
            f = (a, a+1, a+nx+2, a+nx+1)
            rollfaces.append(f)
            rolluv.append([(rollverts[k][0], rollverts[k][1]) for k in f])
    cotton_mesh('Duvet turned-back soft fold', rollverts, rollfaces, rolluv)
    return obj


def bed(w, d, h):
    hb_y = d/2-.025
    # Solid chevron headboard inset within an exceptionally slender brass border.
    b('Bed ash headboard structure', (0, hb_y, .710),
      (w-.014, .050, .980), 'wood', .004)
    # Two repeated diamonds, as opposed to one oversized diagonal grain patch.
    for side in (-1, 1):
        veneer('Headboard chevron book-match', side*(w-.034)/4,
               hb_y-.0255, .710, (w-.034)/2, .958, True,
               phase=(side+1)*.14)
    for sx in (-1, 1):
        b('Bed headboard brass vertical', (sx*(w-.014)/2, hb_y-.025, h/2),
          (.014, .014, h), 'brass', .0015)
    b('Bed headboard brass top', (0, hb_y-.025, h-.007),
      (w, .014, .014), 'brass', .0015)
    # Bed structural rails, slats, and one central underside support.
    for sx in (-1, 1):
        b('Bed ash side rail', (sx*(w/2-.040), -.005, .295),
          (.060, d-.095, .135), 'wood', .004)
    for j in range(14):
        y = -.895+j*.139
        b('Bed sprung ash slat', (0, y, .350),
          (w-.135, .055, .014), 'inside', .002)
    b('Bed central support beam', (0, 0, .305), (.040, d-.140, .060), 'wood', .003)
    for sy in (-1, 1):
        b('Bed hidden central support foot', (0, sy*.690, .152),
          (.035, .035, .285), 'black', .002)
    fy = -d/2+.019
    b('Bed horizontal ash footboard', (0, fy, .330),
      (w-.022, .038, .220), 'wood', .004)
    for sx in (-1, 1):
        b('Bed footboard brass upright', (sx*(w-.014)/2, fy-.012, .229),
          (.014, .014, .458), 'brass', .0015)
    for z in (.011, .219, .445):
        b('Bed footboard brass crossbar', (0, fy-.012, z),
          (w, .014, .014), 'brass', .0015)
    # A softly bevelled mattress remains clearly visible above the side rails.
    b('Bed thick natural cotton mattress', (0, .005, .464),
      (w-.110, d-.165, .218), 'cotton', .055)
    for z in (.386, .548):
        radx, rady = (w-.113)/2, (d-.168)/2
        points = []
        for corner_x, corner_y, start in ((radx-.025, rady-.025, 0),
                                         (-radx+.025, rady-.025, math.pi/2),
                                         (-radx+.025, -rady+.025, math.pi),
                                         (radx-.025, -rady+.025, 3*math.pi/2)):
            for k in range(9):
                t = start+k/8*math.pi/2
                points.append((corner_x+.025*math.cos(t),
                               corner_y+.025*math.sin(t), z))
        c.curve('Mattress tailored piping', points, .0014, 'stitch', cyclic=True)
    duvet(w-.045, seed=12 if w < 1.8 else 14)
    offset = (w-.19)/4
    pw = min(.720, (w-.190)/2)
    pillow('Left upright striped pillow', (-offset, .744, .745),
           width=pw, depth=.470, height=.180, tilt=.900, spin=.015, seed=2)
    pillow('Right upright striped pillow', (offset, .744, .750),
           width=pw, depth=.470, height=.185, tilt=.880, spin=-.025, seed=5)
    pillow('Casually layered white pillow', (.270, .432, .725),
           width=.580, depth=.385, height=.150, tilt=.210, spin=-.180, seed=9)


def create(sku, instance=None):
    """Build any of the fourteen SKUs; safe to call repeatedly in one scene."""
    global _SKU
    if sku not in PRODUCTS:
        raise ValueError('Unknown SIENNA catalogue SKU: '+str(sku))
    old_sku, _SKU = _SKU, sku
    _SERIAL[sku] = _SERIAL.get(sku, 0)+1
    instance_id = instance or (sku+'-'+str(_SERIAL[sku]).zfill(2))
    title, dims = PRODUCTS[sku]
    root = c.empty('SIENNA '+sku+' | '+str(instance_id), props={
        'kind': 'product', 'product_id': sku, 'instance_id': instance_id,
        'title': title, 'width_m': dims[0], 'depth_m': dims[1], 'height_m': dims[2],
        'finish': 'LCV09 Warm Brown', 'material': 'Veneer / Vic Ash Timber',
        'source': 'SIENNA CATALOGUE 2026',
    })
    try:
        with parent(root):
            if sku in ('LV463-B01', 'LV463-B02'):
                bed(*dims)
            elif sku == 'LV463-B42':
                cabinet_bedside(*dims)
            elif sku == 'LV463-B51':
                cabinet_tallboy(*dims)
            elif sku == 'LV463-B61':
                cabinet_dresser(*dims)
            elif sku == 'LV463-B71':
                mirror(*dims)
            elif sku == 'LV463-D01':
                dining(*dims)
            elif sku == 'LV463-L21':
                console(*dims)
            elif sku == 'LV463-D21':
                cabinet_buffet(*dims)
            elif sku in ('LV446-L01', 'LV446-L02'):
                coffee(*dims)
            elif sku == 'LV446-L11':
                lamp_table(*dims)
            elif sku == 'LV446-L12':
                sofa_table(*dims)
            elif sku == 'LV446-L31':
                cabinet_tv(*dims)
    finally:
        _SKU = old_sku
    return root

