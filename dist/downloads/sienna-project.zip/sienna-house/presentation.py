"""Organise the editable master and give it a useful opening camera view."""
import bpy

def organise():
    scene=bpy.context.scene
    def coll(name,parent=None):
        result=bpy.data.collections.get(name) or bpy.data.collections.new(name)
        parent=parent or scene.collection
        if result.name not in parent.children:parent.children.link(result)
        return result
    products=coll('01 | SIENNA catalogue products')
    architecture=coll('02 | Architecture & interpreted styling')
    lights=coll('03 | Lighting & cameras')
    garden=coll('04 | Render garden surroundings')
    room_collections={}
    for room in ['master','guest','living','dining','hall']:
        room_collections[room]=coll(room.upper(),products)
    def ancestor(obj,kind):
        while obj:
            if obj.get('kind')==kind:return obj
            obj=obj.parent
    targets={}
    for ob in list(scene.objects):
        root=ancestor(ob,'product')
        if root:
            key=root.name
            if key not in targets:targets[key]=coll(root.get('product_id')+' | '+root.get('instance_id'),room_collections.get(root.get('room'),products))
            target=targets[key]
        elif ancestor(ob,'exterior'):target=garden
        elif ob.type in {'LIGHT','CAMERA'}:target=lights
        else:target=architecture
        if ob.name not in target.objects:target.objects.link(ob)
        for previous in list(ob.users_collection):
            if previous!=target:previous.objects.unlink(ob)
    scene.timeline_markers.clear()
    for frame,name in [(1,'master'),(31,'dining'),(61,'living'),(91,'guest')]:
        marker=scene.timeline_markers.new(name.title()+' | camera',frame=frame);marker.camera=bpy.data.objects['Camera '+name]
    scene.frame_start=1;scene.frame_end=120;scene.frame_set(1);scene.camera=bpy.data.objects['Camera master']
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type=='VIEW_3D':
                space=area.spaces.active;space.region_3d.view_perspective='CAMERA';space.region_3d.view_camera_zoom=0
                space.overlay.show_floor=False;space.overlay.show_axis_x=False;space.overlay.show_axis_y=False;space.overlay.show_extras=False
                space.shading.type='MATERIAL'
    print('SIENNA_PRESENTATION_READY',len(targets),'product collections',flush=True)

if __name__=='__main__':
    organise();bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
