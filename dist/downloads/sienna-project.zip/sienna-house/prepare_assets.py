"""Create web-sized derivatives of actual Cycles renders and delivery files."""
from pathlib import Path
import sys,shutil,zipfile,json,hashlib
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'.local'/'catalogue-review'/'packages'))
import fitz
site=ROOT/'sites'/'sienna-house';dist=site/'dist';assets=dist/'assets';downloads=dist/'downloads';downloads.mkdir(exist_ok=True)
for name in ['master','dining','living','guest']:
    original=BASE/'renders'/f'{name}-4k.png'
    source=original if original.exists() else BASE/'renders'/f'{name}-preview.png'
    pix=fitz.Pixmap(str(source))
    if pix.width>1920:pix.shrink(1)
    (assets/f'{name}.jpg').write_bytes(pix.tobytes('jpg',jpg_quality=91))
    if original.exists():shutil.copy2(original,downloads/original.name)
master=BASE/'renders'/'master-4k.png'
if not master.exists():master=BASE/'renders'/'master-preview.png'
doc=fitz.open(str(master));pdf=fitz.open('pdf',doc.convert_to_pdf());page=pdf[0]
# Nightstand chevron / brass is part of the actual render, not a catalogue crop.
r=page.rect;clip=fitz.Rect(r.width*.80,r.height*.48,r.width*.99,r.height*.97)
pix=page.get_pixmap(matrix=fitz.Matrix(2,2),clip=clip)
(assets/'detail-wood.jpg').write_bytes(pix.tobytes('jpg',jpg_quality=93))
shutil.copy2(BASE/'sienna-house.blend',downloads/'sienna-house.blend')
shutil.copy2(ROOT/'SIENNA CATALOGUE 2026.pdf',downloads/'SIENNA-CATALOGUE-2026.pdf')
guide=(site/'README.md').read_text(encoding='utf-8')
(downloads/'README.txt').write_text(guide,encoding='utf-8')
# Lossless project ZIP excludes .blend (separate download), renders (separate),
# caches and backups. Includes full-resolution texture source and rebuild code.
with zipfile.ZipFile(downloads/'sienna-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in BASE.rglob('*'):
        if path.is_file() and (path.suffix in ['.py','.md','.json'] or path.parent.name=='textures') and '__pycache__' not in path.parts:
            z.write(path,'sienna-house/'+str(path.relative_to(BASE)).replace('\\','/'))
proof={}
for path in downloads.glob('*'):
    if path.suffix=='.png':
        p=fitz.Pixmap(str(path));proof[path.name]={'width':p.width,'height':p.height,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(downloads/'render-proof.json').write_text(json.dumps(proof,indent=2))
print(json.dumps({'renders':proof,'blend_bytes':(downloads/'sienna-house.blend').stat().st_size,'project_zip_bytes':(downloads/'sienna-project.zip').stat().st_size},indent=2))
