"""Create web-sized derivatives of native Blender renders and delivery files."""
from pathlib import Path
import sys,shutil,zipfile,json,hashlib
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'.local'/'catalogue-review'/'packages'))
import fitz
site=ROOT/'sites'/'sienna-house';dist=site/'dist';assets=dist/'assets';downloads=dist/'downloads';downloads.mkdir(exist_ok=True)
exhibition='--exhibition' in sys.argv
renders=BASE/('exhibition-renders' if exhibition else 'renders')
for name in ['master','dining','living','guest']:
    original=renders/f'{name}-4k.png'
    source=original if original.exists() else renders/f'{name}-preview.png'
    pix=fitz.Pixmap(str(source))
    if pix.width>1920:pix.shrink(1)
    (assets/f'{name}.jpg').write_bytes(pix.tobytes('jpg',jpg_quality=91))
    if original.exists():shutil.copy2(original,downloads/original.name)
if exhibition:
    detail=renders/'detail-wood.png'
    assert detail.exists(), 'Render the exhibition material close-up before packaging.'
    (assets/'detail-wood.jpg').write_bytes(fitz.Pixmap(str(detail)).tobytes('jpg',jpg_quality=93))
else:
    master=renders/'master-4k.png'
    if not master.exists():master=renders/'master-preview.png'
    doc=fitz.open(str(master));pdf=fitz.open('pdf',doc.convert_to_pdf());page=pdf[0]
    # Retain this material close-up when the same products move to the exhibition.
    r=page.rect;clip=fitz.Rect(r.width*.80,r.height*.48,r.width*.99,r.height*.97)
    pix=page.get_pixmap(matrix=fitz.Matrix(2,2),clip=clip)
    (assets/'detail-wood.jpg').write_bytes(pix.tobytes('jpg',jpg_quality=93))
shutil.copy2(BASE/('sienna-exhibition.blend' if exhibition else 'sienna-house.blend'),downloads/'sienna-house.blend')
shutil.copy2(ROOT/'SIENNA CATALOGUE 2026.pdf',downloads/'SIENNA-CATALOGUE-2026.pdf')
guide=(site/'README.md').read_text(encoding='utf-8')
(downloads/'README.txt').write_text(guide,encoding='utf-8')
# Lossless project ZIP excludes .blend (separate download), renders (separate),
# caches and backups. Includes full-resolution texture source and rebuild code.
with zipfile.ZipFile(downloads/'sienna-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in BASE.rglob('*'):
        if path.is_file() and (path.suffix in ['.py','.md','.json'] or path.parent.name=='textures') and '__pycache__' not in path.parts:
            z.write(path,'sienna-house/'+str(path.relative_to(BASE)).replace('\\','/'))
proof={}
for path in downloads.glob('*'):
    if path.suffix=='.png':
        p=fitz.Pixmap(str(path));proof[path.name]={'width':p.width,'height':p.height,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'layout':'exhibition' if exhibition else 'house','engine':'BLENDER_EEVEE' if exhibition else 'CYCLES'}
(downloads/'render-proof.json').write_text(json.dumps(proof,indent=2))
print(json.dumps({'renders':proof,'blend_bytes':(downloads/'sienna-house.blend').stat().st_size,'project_zip_bytes':(downloads/'sienna-project.zip').stat().st_size},indent=2))
