"""Idempotent interior-wood material refinement of the existing master scene."""
import bpy,sys
from pathlib import Path
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base));import core as c
mat=bpy.data.materials.get('Inside');bs=mat.node_tree.nodes.get('Principled BSDF')
if not bs.inputs['Base Color'].is_linked:
    c.image_map(mat,base/'textures'/'warm_brown_ash.png','Base Color')
    c.image_map(mat,base/'textures'/'ash_veneer_nor_gl.jpg','Normal',True,.20)
    c.image_map(mat,base/'textures'/'ash_veneer_Rough.jpg','Roughness',True)
    nodes=mat.node_tree.nodes;links=mat.node_tree.links;uv=nodes.new('ShaderNodeTexCoord');mapping=nodes.new('ShaderNodeMapping');mapping.inputs['Scale'].default_value=(.55,.55,1)
    links.new(uv.outputs['UV'],mapping.inputs['Vector'])
    for node in nodes:
        if node.type=='TEX_IMAGE':links.new(mapping.outputs['Vector'],node.inputs['Vector'])
    bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
print('SIENNA_INTERIOR_WOOD_REFINED',flush=True)
