# SIENNA — The Open Gallery

Website and 3D visualisation by Muhammad Rizky.

Current hosting: https://rizky-make-it.github.io/sienna-house-2026/
Current public repository: https://github.com/rizky-make-it/sienna-house-2026

The latest delivery is an open furniture exhibition: zero walls, partitions,
ceiling, window frames, curtains or wall-mounted ornaments. Four floor-inlay
display zones and freestanding information signs replace the enclosed rooms.
The web tour begins in Orbit mode, with walking between zones and outer aisles.
All 14 catalogue SKUs, 17 placements and 32 moving drawer/door pivots are retained.
The optimised web scene has 442,100 triangles and 50 batched meshes.

Current master: sienna-exhibition.blend (metric, six packed texture images,
four cameras, Cycles-ready). Original sienna-house.blend is preserved unchanged.
Current gallery: exhibition-renders/*-4k.png (Blender EEVEE, 64 samples, UHD 4K).
A fresh wall-free portrait material close-up is rendered for the website.
Original house renders remain in renders/.

The website's legacy filenames assets/sienna-house.glb and
downloads/sienna-house.blend now contain the exhibition, not the enclosed house.
The project ZIP includes the original base scripts plus build_exhibition.py,
render_exhibition.py and the current exhibition metadata. Build the original
base first, then run build_exhibition.py on that saved Blender file.

The Blender audit verifies zero walls/roof, SKU and pivot counts, UVs, metric
scale, packed images and UHD settings. Desktop/mobile browser QA passes Orbit-first
startup, former-wall crossovers, clear zone spawn positions, all 14 models,
raycast selection, cabinet animations, gallery and WhatsApp request dialogs.
No runtime, console or HTTP errors were found. All four 4K image hashes differ.

Creator credit and contact popups are preserved. The owner's requested WhatsApp
placeholder is explicitly a demo: no random number is contacted. Public source
and static assets are not access-controlled. The earlier private Sites deployment
below is historical and is not the current publishing target. Vercel is not used.

## Historical enclosed-house delivery — superseded by the exhibition

Website (private): https://sienna-house.fondsnipe129.chatgpt.site

New GitHub repository (private): https://github.com/rizky-make-it/sienna-house-2026

The published Site and GitHub main were verified against the same source commit:
`7faa8569f187a09cd3ea322c6d2a02250e1aadf7`.

Native deployment status: succeeded.
Site ID: appgprj_6ad637f0a2508191ba20924b0bb46f15
Version: appgprj_6ad637f0a2508191ba20924b0bb46f15~appgver_3c66f21675488191ba2e7cf414172a6f
Deployment: appgdep_6ad64caa84f88191a9588fee663c5375

## Files

- `sienna-house.blend`: editable, metric, six packed texture images, room/SKU
  collections, four camera markers. Blender 5.2+.
- `renders/master-4k.png`, `dining-4k.png`, `living-4k.png`, `guest-4k.png`:
  actual Blender Cycles renders, each 3840 × 2160, lossless PNG.
- Website source: `../../sites/sienna-house/`.
- Web house model: `../../sites/sienna-house/dist/assets/sienna-house.glb`.
- Fourteen individual SKU GLBs: `../../sites/sienna-house/dist/assets/models/`.
- Rebuild scripts and original-resolution textures: this folder and the website's
  `dist/downloads/sienna-project.zip`.
- Manual deployment instructions: `../../sites/sienna-house/README.md`.

## Verified scope

Four connected main rooms plus a gallery hall, 14 catalogue SKUs, 17 placements,
32 moving drawer/door pivots. Queen and King beds are both physically represented.
Browser walking/orbit, raycast product selection, zoom, drawer/door animations,
search/filters, gallery, responsive layout and downloads passed Chrome desktop
1440 × 1000 and mobile emulation 390 × 844 checks, with no runtime or HTTP errors.
The native Blender file passed UV, packed-image, SKU and resolution checks.

This is an independent reconstruction from the supplied catalogue, not official
manufacturer CAD. Unseen construction, architecture and accessories are interpreted.
The web model uses real-time lighting and approximate environment reflections.
Native gallery images use Cycles ray tracing.

Vercel has NOT been deployed: its integration was not installed/connected in this
session. The separate GitHub repository and `vercel.json` are ready for manual
Vercel import: Other framework, no build command, output directory `dist`.

The previous Ruang / Walnut project and the original supplied PDF remain unchanged.
