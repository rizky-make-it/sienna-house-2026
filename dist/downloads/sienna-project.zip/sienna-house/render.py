"""Render selected saved cameras at true UHD 4K. -- master / dining / living / guest / all."""
import bpy,sys,json,time
from pathlib import Path
base=Path(__file__).resolve().parent
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['all']
names=['master','dining','living','guest'] if args[0]=='all' else args[:next((i for i,a in enumerate(args) if a.startswith('--')),len(args))]
preview='--preview' in args
samples=int(args[args.index('--samples')+1]) if '--samples' in args else 40
for name in names:
    started=time.perf_counter()
    scene=bpy.context.scene;scene.camera=bpy.data.objects['Camera '+name]
    scene.render.resolution_percentage=25 if preview else 100
    scene.cycles.samples=12 if preview else samples
    scene.cycles.diffuse_bounces=3;scene.cycles.glossy_bounces=4
    scene.render.filepath=str(base/'renders'/((name+'-preview.png') if preview else (name+'-4k.png')))
    Path(scene.render.filepath).parent.mkdir(parents=True,exist_ok=True)
    bpy.ops.render.render(write_still=True)
    (base/'renders'/(name+'-render-settings.json')).write_text(json.dumps({'camera':name,'engine':'Cycles CPU','samples':scene.cycles.samples,'denoising':scene.cycles.use_denoising,'width':round(scene.render.resolution_x*scene.render.resolution_percentage/100),'height':round(scene.render.resolution_y*scene.render.resolution_percentage/100),'seconds':time.perf_counter()-started},indent=2))
    print('SIENNA_RENDER_COMPLETE',name,scene.render.filepath,flush=True)
