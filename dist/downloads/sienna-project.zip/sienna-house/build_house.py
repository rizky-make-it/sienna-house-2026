"""Build one connected, furnished SIENNA house. All coordinates in metres."""
import bpy, math, json, sys, random
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
import core as c
import furniture
random.seed(2026)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
c.materials()
COLLIDERS=[];PLACEMENTS=[]
def wall(name,loc,dims):
    ob=c.box(name,loc,dims,'plaster',.008);ob['kind']='wall'
    if loc[2]-dims[2]/2<1.7:COLLIDERS.append([loc[0]-dims[0]/2,loc[1]-dims[1]/2,loc[0]+dims[0]/2,loc[1]+dims[1]/2])
    return ob
def rail(name,a,b,z=.12):
    c.rod(name,(a[0],a[1],z),(b[0],b[1],z),.011,'trim')
def panel(x1,x2,y,z1=.30,z2=2.43):
    points=[(x1,y,z1),(x2,y,z1),(x2,y,z2),(x1,y,z2)]
    c.curve('Raised classical wall moulding',points,.009,'trim',True)
def curtain(name,loc,width=1.1,height=2.8):
    verts=[];faces=[];uv=[];nx=44;nz=56
    for j in range(nz+1):
        t=j/nz
        for i in range(nx+1):
            u=i/nx;x=(u-.5)*width
            y=.065*math.cos(u*math.tau*7)+.013*math.sin(t*11+u*31)*(t**1.5)
            z=-t*height+.025*math.cos(u*math.tau*7)*(t**8)
            verts.append((loc[0]+x,loc[1]+y,loc[2]+z));uv.append((u*width,t*height))
    for j in range(nz):
        for i in range(nx):
            q=j*(nx+1)+i;faces.append((q,q+1,q+nx+2,q+nx+1))
    ob=c.mesh(name,verts,faces,'linen',uv,True);s=ob.modifiers.new('Hem thickness','SOLIDIFY');s.thickness=.002
    c.curve('Curtain weighted lower hem',verts[-nx-1:],.003,'stitch')
def window(name,x1,x2,y):
    # North-facing glazing with real wall opening, sill, mullions and drapes.
    z1=.60;z2=2.75
    c.box(name+' glass',((x1+x2)/2,y,1.675),(x2-x1,.018,2.15),'glass',.001)['kind']='windowglass'
    for x in [x1,(x1+x2)/2,x2]:c.box('Window black steel mullion',(x,y-.025,1.675),(.028,.055,2.2),'black',.002)
    for z in [z1,1.55,z2]:c.box('Window transom',((x1+x2)/2,y-.025,z),(x2-x1+.04,.055,.028),'black',.002)
    c.box('Painted deep window sill',((x1+x2)/2,y-.075,z1-.035),(x2-x1+.18,.25,.07),'trim',.01)
    c.box('Roman blind rolled linen',((x1+x2)/2,y-.07,2.68),(x2-x1+.10,.09,.18),'linen',.02)
    for z in [2.61,2.65,2.70]:c.box('Blind fold seam',((x1+x2)/2,y-.12,z),(x2-x1,.01,.008),'stitch',.002)
    c.rod('Brass curtain pole',(x1-.45,y-.22,2.91),(x2+.45,y-.22,2.91),.014,'brass')
    curtain('Left pleated linen curtain',(x1-.25,y-.22,2.9),.62,2.84)
    curtain('Right pleated linen curtain',(x2+.25,y-.22,2.9),.62,2.84)
def north_wall(start,end,y,openings):
    cursor=start
    for a,b in openings:
        if a>cursor:wall('Window wall pier',((a+cursor)/2,y,1.52),(a-cursor,.18,3.04))
        wall('Wall under window',((a+b)/2,y,.30),(b-a,.18,.60))
        wall('Wall above window',((a+b)/2,y,2.895),(b-a,.18,.29))
        window('Glazed garden window',a,b,y)
        cursor=b
    if cursor<end:wall('Window wall pier',((end+cursor)/2,y,1.52),(end-cursor,.18,3.04))
def doorway_wall(y,doors):
    cursor=0
    for a,b in doors:
        if a>cursor:wall('Internal partition',((cursor+a)/2,y,1.52),(a-cursor,.14,3.04))
        wall('Door lintel',((a+b)/2,y,2.69),(b-a,.14,.70))
        for x in [a-.035,b+.035]:c.box('Door moulded casing',(x,y-.095,1.18),(.075,.055,2.36),'trim',.005)
        c.box('Door casing header',((a+b)/2,y-.095,2.34),(b-a+.15,.055,.075),'trim',.005)
        cursor=b
    if cursor<12:wall('Internal partition',((cursor+12)/2,y,1.52),(12-cursor,.14,3.04))
def vase(loc,scale=1,mat='ceramic',flowers=False):
    x,y,z=loc
    profile=[(.001,0),(.070,0),(.096,.035),(.11,.13),(.072,.23),(.040,.28),(.042,.30),(.034,.30),(.033,.275),(.063,.224),(.094,.126),(.080,.045),(.001,.025)]
    c.lathe('Hand-thrown ceramic vase',loc,[(r*scale,h*scale) for r,h in profile],mat)
    if flowers:
        for n in range(7):
            a=n*2.4;h=(.5+random.random()*.3)*scale
            tip=(x+math.cos(a)*.18*scale,y+math.sin(a)*.13*scale,z+h)
            c.curve('Dried olive branch',[(x,y,z+.22*scale),(x+math.cos(a)*.07,y,z+h*.7),tip],.0022*scale,'inside')
            for j in range(5):
                t=.45+j*.1;px=x+(tip[0]-x)*t;py=y+(tip[1]-y)*t;pz=z+h*t
                leaf=c.sphere('Olive leaf',(px+.018*math.cos(a+j),py+.03*math.sin(a+j),pz),(.012*scale,.038*scale,.005*scale),'leaf',12,6);leaf.rotation_euler=(.4,.3,a+j)
def books(loc,count=3):
    x,y,z=loc
    for i in range(count):
        a=.24+random.random()*.03;b=.18+random.random()*.03;h=.028+random.random()*.015
        c.box('Linen bound book',(x,y,z+h/2),(a,b,h),'linen',.003)
        c.box('Book deckled pages',(x,y-.002,z+h/2),(a-.012,b-.012,h-.008),'paper',.001);z+=h+.002
def chair(loc,angle=0):
    parent=c.PARENT;root=c.empty('Boucle dining chair | interpreted accessory',loc);root.rotation_euler.z=angle;c.set_parent(root)
    for x in [-.20,.20]:
        for y in [-.19,.19]:c.rod('Tapered ash chair leg',(x*1.07,y*1.06,.025),(x,y,.47),.019,'wood')
    c.box('Chair upholstered seat',(0,-.015,.46),(.48,.46,.12),'linen',.055)
    # Curved upholstered wraparound back and solid wood support rail.
    verts=[];faces=[];nx=32;nz=8
    for j in range(nz+1):
        for i in range(nx+1):
            a=math.pi*(.10+.80*i/nx);x=.275*math.cos(a);y=.04+.21*math.sin(a);z=.64+j/nz*.22
            verts.append((x,y,z))
    for j in range(nz):
        for i in range(nx):q=j*(nx+1)+i;faces.append((q,q+1,q+nx+2,q+nx+1))
    ob=c.mesh('Curved boucle backrest',verts,faces,'linen',smooth=True);mod=ob.modifiers.new('Upholstery depth','SOLIDIFY');mod.thickness=.045
    c.curve('Ash backrest lower rail',[(.29*math.cos(a),.04+.22*math.sin(a),.63) for a in [math.pi*(.1+.8*i/40) for i in range(41)]],.017,'wood')
    for x in [-.23,.23]:c.rod('Backrest stile',(x,.17,.4),(x,.17,.78),.014,'wood')
    c.set_parent(parent)
def sofa(loc):
    root=c.empty('Quiet linen sofa | interpreted accessory',loc);c.set_parent(root)
    c.box('Sofa upholstered plinth',(0,0,.23),(2.6,.88,.32),'linen',.09)
    c.box('Sofa back',(0,.38,.67),(2.6,.22,.74),'linen',.10)
    for x in [-1.23,1.23]:c.box('Sofa padded arm',(x,-.02,.53),(.19,.93,.61),'linen',.085)
    for x in [-.75,0,.75]:
        c.box('Soft linen seat cushion',(x,-.09,.46),(.73,.72,.20),'linen',.09)
        ob=c.box('Relaxed sofa back cushion',(x,.22,.77),(.72,.18,.52),'linen',.085);ob.rotation_euler.x=math.radians(9)
        c.curve('Cushion piped seam',[(x-.32,-.42,.49),(x+.32,-.42,.49),(x+.32,.22,.49),(x-.32,.22,.49)],.002,'stitch',True)
    for x in [-1.1,1.1]:
        for y in [-.29,.29]:c.cylinder('Sofa brass foot',(x,y,.09),.018,.18,'brass')
    c.set_parent(None)
def rug(loc,size):
    ob=c.box('Woven wool rug',loc,(size[0],size[1],.018),'rug',.035)
    x,y,z=loc;w,h=size
    for t in [0,.025]:c.curve('Rug bound perimeter',[(x-w/2+t,y-h/2+t,z+.011),(x+w/2-t,y-h/2+t,z+.011),(x+w/2-t,y+h/2-t,z+.011),(x-w/2+t,y+h/2-t,z+.011)],.003,'linen',True)
def product(sku,loc,angle=0,room='master',instance=None):
    c.set_parent(None);root=furniture.create(sku,instance);root.location=loc;root.rotation_euler.z=math.radians(angle);root['room']=room
    PLACEMENTS.append({'sku':sku,'instance':root.get('instance_id',root.name),'object':root.name,'room':room,'position':list(loc),'rotation':angle})
    # Detailed scene graph is retained; walk collision uses footprint, not thin handles.
    if sku!='LV463-B71':
        dims=furniture.DIMENSIONS[sku] if hasattr(furniture,'DIMENSIONS') else None
    c.set_parent(None);return root

# A connected 126m² single-storey house: not four independent platforms.
c.box('House slab',(6,5.25,-.11),(12.2,10.7,.22),'trim',.035)
for row in range(35):
    y=.15+row*.30
    for i in range(8):
        x=i*1.7-(row%3)*.55;start=max(0,x);end=min(12,x+1.698)
        if end>start:c.box('Ash floorboard',((start+end)/2,y,-.005),(end-start,.297,.025),'floor',.001)
for x in [0,12]:wall('Outer side wall',(x,5.25,1.52),(.18,10.5,3.04))
north_wall(0,12,10.5,[(.65,1.65),(3.85,5.0),(6.65,7.65),(10.3,11.4)])
north_wall(0,12,0,[(.6,2.2),(3.8,5.3),(7,8.4),(9.8,11.3)])
doorway_wall(4.65,[(4.45,5.65),(7.0,8.2)])
doorway_wall(6.0,[(4.45,5.65),(7.0,8.2)])
wall('Bedroom dividing wall',(6,8.25,1.52),(.14,4.5,3.04))
for a,b in [(0,1.15),(3.7,4.65)]:wall('Open plan dining partition',(6,(a+b)/2,1.52),(.14,b-a,3.04))
wall('Living dining arch lintel',(6,2.425,2.72),(.14,2.55,.64))
for y in [1.15,3.7]:c.box('Open arch casing',(5.92,y,1.2),(.055,.075,2.4),'trim',.004)
for y in [0,4.65,6,10.5]:
    for a,b in ([(0,4.40),(5.7,6.95),(8.25,12)] if y in [4.65,6] else [(0,12)]):
        c.box('Painted skirting',((a+b)/2,y+.1 if y==0 else y-.1,.095),(b-a,.036,.19),'trim',.006)
        c.box('Layered cornice',((a+b)/2,y+.11 if y==0 else y-.11,2.98),(b-a,.13,.10),'trim',.012)
for x in [.11,11.89]:
    c.box('Side skirting',(x,5.25,.095),(.04,10.5,.19),'trim',.005)
    c.box('Side cornice',(x,5.25,2.98),(.13,10.5,.10),'trim',.01)
for x1,x2 in [(.35,1.75),(1.95,3.45),(3.65,4.25),(8.4,9.85),(10.05,11.65)]:panel(x1,x2,4.54)
for x1,x2 in [(1.95,3.6),(7.95,10.05)]:panel(x1,x2,10.39,1.37,2.7)
ceiling=c.box('Continuous plaster ceiling',(6,5.25,3.11),(12.2,10.7,.14),'plaster',.01);ceiling['kind']='ceiling'
# Furnish all fourteen catalogue SKUs, both beds physically present.
product('LV463-B02',(2.75,9.07,0),room='master')
product('LV463-B42',(1.38,9.80,0),room='master',instance='master-left')
product('LV463-B42',(4.12,9.80,0),room='master',instance='master-right')
product('LV463-B51',(5.68,8.90,0),-90,'master')
product('LV463-B61',(.34,7.37,0),90,'master')
product('LV463-B71',(.12,7.37,1.03),90,'master')
product('LV463-B01',(8.65,9.07,0),room='guest')
product('LV463-B42',(7.45,9.8,0),room='guest',instance='guest-left')
product('LV463-B42',(9.85,9.8,0),room='guest',instance='guest-right')
product('LV446-L02',(10.65,7.5,0),room='guest')
product('LV463-D01',(9.1,2.35,0),room='dining')
product('LV463-D21',(9.45,4.31,0),room='dining')
product('LV463-L21',(6.1,5.78,0),room='hall')
product('LV446-L01',(2.8,2.17,0),room='living')
product('LV446-L11',(1.12,3.68,0),room='living')
product('LV446-L12',(4.50,3.48,0),room='living')
product('LV446-L31',(2.95,.37,0),180,'living')
sofa((2.85,3.75,0));rug((2.9,2.42,.024),(3.8,3.16));rug((9.1,2.35,.024),(4.15,3.24))
rug((2.75,8.6,.025),(3.6,3.3));rug((8.65,8.7,.025),(3.2,3.2))
for x in [8.38,9.1,9.82]:
    chair((x,1.43,0),0);chair((x,3.27,0),math.pi)
chair((7.57,2.35,0),-math.pi/2);chair((10.63,2.35,0),math.pi/2)
chair((10.74,8.64,0),0)
for loc in [(1.38,9.80,.55),(4.12,9.8,.55),(7.45,9.8,.55),(9.85,9.8,.55)]:vase(loc,.65,flowers=True)
vase((9.0,4.28,.82),1.15,flowers=True);vase((10.05,4.28,.82),.7);vase((9.15,2.35,.77),.60,flowers=True)
vase((6.45,5.78,.76),.7,flowers=True);books((5.7,5.78,.76),3);books((2.65,2.17,.44),3);vase((3.13,2.17,.44),.60)
books((.34,7.27,.80),3);vase((.34,7.85,.80),.7,flowers=True);books((10.65,7.5,.44),3)
# Quiet, dimensional landscape studies above the beds; interpreted styling.
for base_x in [2.75,8.65]:
    for dx in [-.39,.39]:
        x=base_x+dx;y=10.36;z=2.15
        c.box('Landscape study ash frame',(x,y,z),(.66,.035,.67),'wood',.004)
        c.box('Landscape study linen mat',(x,y-.02,z),(.61,.008,.62),'paper',.001)
        c.box('Landscape study olive ground',(x,y-.027,z),(.50,.004,.49),'sage',.001)
        for j in range(6):
            points=[(x-.25+i/50*.5,y-.031-j*.0005,z-.22+j*.075+.018*math.sin(i*.2+j)) for i in range(51)]
            c.curve('Landscape contour',points,.012,'linen' if j%2 else 'leaf')
# The catalogue dining-room styling uses an ornate brass-coloured mirror.
mirror_outline=[(9.45+(.57+.018*math.cos(8*t))*math.cos(t),4.515,1.88+(.62+.018*math.cos(8*t))*math.sin(t)) for t in [i*math.tau/128 for i in range(128)]]
c.mesh('Dining decorative mirror',mirror_outline,[tuple(range(128))],'mirror')
c.curve('Scalloped dining mirror brass frame',[(9.45+(.59+.018*math.cos(8*t))*math.cos(t),4.49,1.88+(.64+.018*math.cos(8*t))*math.sin(t)) for t in [i*math.tau/160 for i in range(160)]],.014,'brass',True)
# TV, local studio accessories, glass globe lighting.
c.box('Thin framed television',(2.95,.15,1.28),(1.43,.035,.82),'black',.014)
screen=c.material('Television softly reflecting room',(.09,.12,.11),.19,.35);c.box('TV dark glass screen',(2.95,.175,1.28),(1.38,.008,.77),screen,.008)
for x in [1.38,4.12,7.45,9.85]:
    c.rod('Pendant flex',(x,9.75,3.02),(x,9.75,1.38),.003,'black');c.sphere('Clear pendant globe',(x,9.75,1.38),(.115,.115,.115),'glass');c.sphere('Warm pendant capsule',(x,9.75,1.38),(.018,.018,.04),'light',16,8)
    c.cylinder('Pendant brass cap',(x,9.75,1.50),.027,.04,'brass');c.light('Bed pendant glow','POINT',(x,9.75,1.38),12,(1,.68,.36))
for x in [8,10.9]:
    c.cylinder('Sconce wall plate',(x,4.49,1.8),.065,.025,'brass').rotation_euler.x=math.pi/2
    c.rod('Sconce stem',(x,4.46,1.5),(x,4.3,1.92),.009,'brass')
    c.lathe('Linen sconce shade',(x,4.3,1.9),[(.095,0),(.055,.18)],'cotton')
    c.light('Sconce warm light','POINT',(x,4.27,1.95),15,(1,.72,.42))
c.rod('Chandelier cable',(9.1,2.35,3.02),(9.1,2.35,2.2),.005,'brass')
for i in range(19):
    a=i*2.4;r=.18+.25*(i%3)/2;z=2.12+.19*math.sin(i*2.7)
    loc=(9.1+r*math.cos(a),2.35+r*.6*math.sin(a),z)
    c.sphere('Chandelier clear blown glass bubble',loc,(.112,.112,.112),'glass',24,12)
    if i%4==0:c.sphere('Chandelier warm lamp',loc,(.015,.015,.023),'light',12,8)
c.light('Chandelier pool','POINT',(9.1,2.35,2.25),80,(1,.79,.51))
c.lathe('Table lamp linen shade',(1.12,3.68,.88),[(.15,0),(.105,.25)],'cotton');c.rod('Table lamp brass stem',(1.12,3.68,.55),(1.12,3.68,.95),.012,'brass');c.cylinder('Table lamp base',(1.12,3.68,.565),.085,.025,'brass');c.light('Living table lamp','POINT',(1.12,3.68,.96),14,(1,.75,.45))
# Soft sky and actual ray-traced sunlight; exterior foliage visible through windows.
world=bpy.data.worlds.new('Pale warm daylight');world.use_nodes=True;world.node_tree.nodes.get('Background').inputs[0].default_value=(.72,.82,1,1);world.node_tree.nodes.get('Background').inputs[1].default_value=.45;bpy.context.scene.world=world
c.light('Daylight master windows','AREA',(1,12,3.7),650,(1,.89,.72),(2.8,8.4,.8),4.5)
c.light('Daylight guest windows','AREA',(9,12,3.7),650,(1,.89,.72),(8.7,8.4,.8),4.5)
c.light('Daylight living windows','AREA',(2,-2,3.8),700,(1,.91,.77),(2.8,2.6,.7),4.3)
c.light('Daylight dining windows','AREA',(9,-2,3.8),650,(1,.91,.77),(9,2.6,.7),4.3)
sun=c.light('Low afternoon sun','SUN',(-10,15,15),2.0,(1,.87,.65),(6,4,0));sun.data.angle=.075
for loc in [(2.6,8,2.8),(8.8,8,2.8),(3,2.7,2.8),(9,2.5,2.8),(6,5.3,2.7)]:c.light('Gentle interior bounce','AREA',loc,65,(1,.92,.81),(loc[0],loc[1],0),3)
outside=c.empty('Garden | render surroundings',props={'kind':'exterior'});c.set_parent(outside)
c.box('Garden ground',(6,5,-.16),(70,70,.10),'leaf',.02)
for i in range(22):
    x=-4+random.random()*20;y=random.choice([-5,15])+random.random()*2;h=random.uniform(2.8,5.2)
    c.rod('Garden tree trunk',(x,y,0),(x,y,h),.06,'inside')
    for j in range(5):c.sphere('Soft distant olive canopy',(x+random.uniform(-.6,.6),y+random.uniform(-.5,.5),h+random.uniform(-.3,.5)),(.65,.65,.8),'leaf',16,8)
c.set_parent(None)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='METERS'
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=40;scene.cycles.use_denoising=True;scene.cycles.adaptive_threshold=.035;scene.cycles.max_bounces=8;scene.cycles.transmission_bounces=6
scene.render.threads_mode='FIXED';scene.render.threads=6
scene.render.resolution_x=3840;scene.render.resolution_y=2160;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8'
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.4
CAMERAS={'master':((4.93,6.40,1.65),(2.72,9.05,.82),29),'dining':((6.65,.55,1.65),(9.10,2.65,.95),22),'living':((5.46,4.27,1.65),(2.60,1.75,.72),27),'guest':((11.45,6.48,1.65),(8.72,9.02,.82),30)}
for name,(loc,target,lens) in CAMERAS.items():
    data=bpy.data.cameras.new('Camera '+name);data.lens=lens;data.clip_start=.07;data.clip_end=200
    ob=c.link(bpy.data.objects.new('Camera '+name,data));ob.location=loc;ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler();data.dof.use_dof=True;data.dof.focus_distance=(Vector(target)-ob.location).length;data.dof.aperture_fstop=7.1
scene.camera=bpy.data.objects['Camera master']
scene['source']='SIENNA CATALOGUE 2026.pdf / 6 pages';scene['interpretation']='Connected house and unseen construction are designed interpretations, not manufacturer CAD.'
scene['sku_count']=14
for image in bpy.data.images:
    if image.source=='FILE' and not image.packed_file:image.pack()
# More curvature at glancing duvet edges in the offline render, without raising
# the browser's base mesh budget.
for ob in bpy.data.objects:
    if ob.name.startswith(('Soft linen','Relaxed sofa','Sofa padded','Sofa upholstered','Sofa back')):
        for p in ob.data.polygons:p.use_smooth=True
        for m in ob.modifiers:
            if m.type=='BEVEL':m.segments=8
    if ob.name.startswith('Sculpted striped white duvet'):
        mod=ob.modifiers.new('Render-only soft cloth curvature','SUBSURF');mod.levels=0;mod.render_levels=1
import presentation
presentation.organise()
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'sienna-house.blend'))
report={'units':'metres','rooms':{'master':{'name':'Master bedroom','bounds':[0,6,6,10.5],'camera':CAMERAS['master']},'guest':{'name':'Guest & reading room','bounds':[6,6,12,10.5],'camera':CAMERAS['guest']},'living':{'name':'Living room','bounds':[0,0,6,4.65],'camera':CAMERAS['living']},'dining':{'name':'Dining room','bounds':[6,0,12,4.65],'camera':CAMERAS['dining']},'hall':{'name':'Gallery hall','bounds':[0,4.65,12,6]}},'colliders':COLLIDERS,'placements':PLACEMENTS}
(BASE/'scene.json').write_text(json.dumps(report,indent=2))
print('SIENNA_BUILD_COMPLETE',len(bpy.data.objects),'objects',flush=True)
