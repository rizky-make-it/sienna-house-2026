"""Render the new exhibition, leaving the original house render files intact.

-- all [--preview] [--cycles] [--samples N]
"""
import bpy,sys,json,time
from pathlib import Path
BASE=Path(__file__).resolve().parent
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['all']
preview='--preview' in args
names=['master','dining','living','guest'] if args[0]=='all' else [args[0]]
scene=bpy.context.scene
assert scene.get('layout')=='exhibition'
cycles='--cycles' in args
scene.render.engine='CYCLES' if cycles else 'BLENDER_EEVEE'
samples=int(args[args.index('--samples')+1]) if '--samples' in args else (16 if preview else 64)
scene.cycles.samples=samples;scene.eevee.taa_render_samples=samples
scene.render.resolution_percentage=25 if preview else 100
out=BASE/'exhibition-renders';out.mkdir(exist_ok=True)
for name in names:
    started=time.perf_counter()
    scene.frame_set({'master':1,'dining':31,'living':61,'guest':91}[name])
    scene.camera=bpy.data.objects['Camera '+name]
    scene.render.filepath=str(out/(f'{name}-'+('preview.png' if preview else '4k.png')))
    bpy.ops.render.render(write_still=True)
    report={'camera':name,'engine':scene.render.engine,'samples':samples,'width':round(scene.render.resolution_x*scene.render.resolution_percentage/100),'height':round(scene.render.resolution_y*scene.render.resolution_percentage/100),'seconds':time.perf_counter()-started,'layout':'exhibition','walls':0}
    (out/f'{name}-render-settings.json').write_text(json.dumps(report,indent=2))
    print('SIENNA_EXHIBITION_RENDER',json.dumps(report),flush=True)

if args[0]=='all' and not preview:
    # A fresh, wall-free material close-up for the website's portrait detail panel.
    scene.frame_set(1);camera=bpy.data.objects['Camera master'];scene.camera=camera
    from mathutils import Vector
    camera.location=(5.25,8.45,1.15);target=Vector((4.12,9.8,.38))
    camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.lens=75;camera.data.sensor_fit='VERTICAL';camera.data.dof.use_dof=False
    scene.render.resolution_x=1600;scene.render.resolution_y=2100
    scene.render.filepath=str(out/'detail-wood.png')
    bpy.ops.render.render(write_still=True)
    print('SIENNA_EXHIBITION_DETAIL_COMPLETE',scene.render.filepath,flush=True)
