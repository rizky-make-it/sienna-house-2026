"""Derivative GLBs: retain products and moving pivots; batch static meshes."""
import bpy,sys,json,math
from pathlib import Path
from collections import defaultdict
from mathutils import Matrix
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE));import furniture
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
OUT=Path(args[0]).resolve() if args else BASE/'web-export'
OUT.mkdir(parents=True,exist_ok=True);(OUT/'models').mkdir(exist_ok=True)
scene=bpy.context.scene
original=list(scene.objects)
def ancestor(obj,kind):
    while obj:
        if obj.get('kind')==kind:return obj
        obj=obj.parent
    return None
products=[o for o in original if o.get('kind')=='product']
articulations=[o for o in original if o.get('kind')=='articulation']
for im in bpy.data.images:
    if im.size[0]>1024 and im.name!='Render Result':im.scale(1024,1024)
# Textured Principled inputs survive glTF; procedural micro-bump falls back to satin.
for mat in bpy.data.materials:
    if not mat.use_nodes:continue
    bs=mat.node_tree.nodes.get('Principled BSDF')
    if bs and bs.inputs['Normal'].is_linked:
        node=bs.inputs['Normal'].links[0].from_node
        if node.type=='BUMP':mat.node_tree.links.remove(bs.inputs['Normal'].links[0])
    if bs and mat.name.lower().startswith('mirror'):
        bs.inputs['Metallic'].default_value=.85;bs.inputs['Roughness'].default_value=.09
groups=defaultdict(list)
for obj in original:
    if obj.type not in {'MESH','CURVE'}:continue
    if obj.get('kind') in ['ceiling','windowglass'] or ancestor(obj,'exterior'):continue
    owner=ancestor(obj,'articulation') or ancestor(obj,'product')
    groups[owner].append(obj)
dg=bpy.context.evaluated_depsgraph_get();batches=[];triangles=0
for owner,objects in groups.items():
    verts=[];faces=[];uvs=[];normals=[];smooth=[];indices=[];materials=[];mi={}
    inverse=owner.matrix_world.inverted_safe() if owner else Matrix.Identity(4)
    for obj in objects:
        ev=obj.evaluated_get(dg);data=ev.to_mesh(preserve_all_data_layers=True,depsgraph=dg)
        if not data:continue
        data.calc_loop_triangles();matrix=inverse@obj.matrix_world;nmat=matrix.to_3x3().inverted_safe().transposed();offset=len(verts)
        verts.extend([tuple(matrix@v.co) for v in data.vertices])
        for tri in data.loop_triangles:
            mat=data.materials[tri.material_index] if data.materials else None
            if mat is not None:mat=bpy.data.materials.get(mat.name)
            if mat is None:mat=bpy.data.materials.get('Plaster')
            if mat.name not in mi:mi[mat.name]=len(materials);materials.append(mat)
            indices.append(mi[mat.name]);smooth.append(tri.use_smooth);faces.append(tuple(offset+i for i in tri.vertices))
            for vi,li in zip(tri.vertices,tri.loops):
                uvs.extend(tuple(data.uv_layers.active.data[li].uv) if data.uv_layers.active else (0,0))
                normals.append(tuple((nmat@data.corner_normals[li].vector).normalized()))
        ev.to_mesh_clear()
    data=bpy.data.meshes.new((owner.name if owner else 'Architecture')+' optimized');data.from_pydata(verts,[],faces);data.update()
    for mat in materials:data.materials.append(mat)
    for p,index,sm in zip(data.polygons,indices,smooth):p.material_index=index;p.use_smooth=sm
    layer=data.uv_layers.new(name='UVMap');layer.data.foreach_set('uv',uvs);data.normals_split_custom_set(normals)
    ob=bpy.data.objects.new(data.name,data);scene.collection.objects.link(ob)
    if owner:ob.parent=owner
    batches.append(ob);triangles+=len(faces)
    print('SIENNA_BATCH',owner.name if owner else 'House',len(faces),flush=True)
# Keep originals unselected rather than removing them: Blender 5.2's evaluated
# curve datablocks can still be referenced until the dependency graph refreshes.
scene.camera=None
for obj in original:
    if obj.type in {'MESH','CURVE','LIGHT','CAMERA'}:obj.hide_render=True;obj.hide_set(True)
def select(objects):
    for ob in scene.objects:ob.select_set(False)
    for ob in objects:ob.select_set(True)
def export(path):
    bpy.ops.export_scene.gltf(filepath=str(path),export_format='GLB',use_selection=True,export_yup=True,export_normals=True,export_tangents=True,export_materials='EXPORT',export_animations=False,export_cameras=False,export_lights=False,export_extras=True,export_draco_mesh_compression_enable=True,export_draco_mesh_compression_level=6,export_draco_position_quantization=14,export_draco_normal_quantization=10,export_draco_texcoord_quantization=12)
select(batches+products+articulations);export(OUT/'sienna-house.glb')
seen=set();report=[]
for root in products:
    sku=root.get('product_id')
    if sku in seen:continue
    seen.add(sku);descendants=[o for o in root.children_recursive if o in batches or o in articulations];savedloc=root.location.copy();savedrot=root.rotation_euler.copy()
    root.location=(0,0,0);root.rotation_euler=(0,0,0);select([root]+descendants);export(OUT/'models'/f'{sku}.glb')
    root.location=savedloc;root.rotation_euler=savedrot
    title,dimensions=furniture.PRODUCTS[sku]
    report.append({'sku':sku,'name':title,'dimensions':[round(v*1000) for v in dimensions],'room':root.get('room'),'model':f'assets/models/{sku}.glb','articulations':sum(1 for o in descendants if o.get('kind')=='articulation')})
(OUT/'products.json').write_text(json.dumps(report,indent=2))
(OUT/'scene.json').write_text((BASE/'scene.json').read_text())
(BASE/'export-report.json').write_text(json.dumps({'products':len(seen),'placements':len(products),'moving_parts':len(articulations),'triangles':triangles,'house_bytes':(OUT/'sienna-house.glb').stat().st_size,'meshes':len(batches)},indent=2))
print('SIENNA_EXPORT_COMPLETE',triangles,'triangles',flush=True)
