"""Convert the original saved house into an open SIENNA furniture exhibition.

Run with Blender --background sienna-house.blend --python build_exhibition.py.
The original house is never overwritten; output is sienna-exhibition.blend.
"""
import bpy, json, math, sys, random
from pathlib import Path
from mathutils import Vector

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import core as c
import presentation

scene = bpy.context.scene
assert not scene.get('layout') == 'exhibition', 'Open the original house before rebuilding.'
random.seed(2026)

def ancestor(ob, kind):
    while ob:
        if ob.get('kind') == kind:
            return ob
        ob = ob.parent

materials = {
    'wood':'LCV09 Warm Brown | photographed ash veneer', 'brass':'Brass',
    'inside':'Inside', 'linen':'Linen', 'paper':'Paper', 'leaf':'Leaf',
    'black':'Black', 'ceramic':'Ceramic', 'trim':'Trim', 'soil':'Soil',
}
for key, name in materials.items():
    if name in bpy.data.materials:
        c.M[key] = bpy.data.materials[name]
c.M['stone'] = c.material('Gallery | warm limestone microcement', (.67,.65,.59), .78)
c.M['plinth'] = c.material('Gallery | chalk display bases', (.79,.76,.68), .65)
c.M['sign'] = c.material('Gallery | forest-green typography', (.055,.077,.056), .8)
c.M['light'] = c.material('Gallery | luminous track lens', (.96,.85,.63), .4)
bs = c.M['light'].node_tree.nodes.get('Principled BSDF')
bs.inputs['Emission Color'].default_value = (1,.82,.55,1)
bs.inputs['Emission Strength'].default_value = 2

remove_prefixes = (
    'Ash floorboard', 'House slab', 'Window black', 'Window transom',
    'Painted deep window', 'Roman blind', 'Blind fold', 'Brass curtain',
    'Left pleated', 'Right pleated', 'Curtain weighted', 'Door moulded',
    'Door casing', 'Open arch casing', 'Painted skirting', 'Layered cornice',
    'Side skirting', 'Side cornice', 'Raised classical wall', 'Landscape study',
    'Landscape contour', 'Dining decorative mirror', 'Scalloped dining mirror',
    'Pendant flex', 'Clear pendant', 'Warm pendant', 'Pendant brass',
    'Sconce ', 'Linen sconce', 'Chandelier ',
)
removed = []
remove_objects = []
for ob in list(scene.objects):
    if ancestor(ob, 'product'):
        continue
    if (ob.type == 'LIGHT' or ancestor(ob, 'exterior') or
        ob.get('kind') in {'wall','ceiling','windowglass'} or
        ob.name.startswith(remove_prefixes)):
        remove_objects.append(ob)
# Resolve descendants before unlinking their exterior parent.
for ob in remove_objects:
    removed.append(ob.name)
    bpy.data.objects.remove(ob, do_unlink=True)

c.set_parent(None)
staging = c.empty('SIENNA | The Open Gallery', props={'kind':'exhibition'})
c.set_parent(staging)
floor = c.box('Exhibition continuous floor', (6,5.3,-.10), (15,13,.20), 'stone', .055)
floor['kind'] = 'exhibition-floor'
zones = {
    'master': {'label':'KING SUITE', 'center':(3,8.25), 'size':(5.7,4.2)},
    'guest': {'label':'QUEEN & READING', 'center':(9,8.25), 'size':(5.7,4.2)},
    'living': {'label':'LIVING COLLECTION', 'center':(3,2.35), 'size':(5.7,4.3)},
    'dining': {'label':'DINING COLLECTION', 'center':(9,2.35), 'size':(5.7,4.3)},
}
for key, zone in zones.items():
    x,y = zone['center']; w,h = zone['size']
    # Very shallow floor inlays define displays without walls or trip-height steps.
    c.box('Display floor | '+key, (x,y,-.014), (w,h,.028), 'plinth', .018)['kind']='display-base'
    c.curve('Brass floor inlay | '+key, [(x-w/2,y-h/2,.004),(x+w/2,y-h/2,.004),(x+w/2,y+h/2,.004),(x-w/2,y+h/2,.004)], .004, 'brass', True)

colliders = []
def text(name, body, loc, size, material='sign', back=False):
    data = bpy.data.curves.new(name, 'FONT'); data.body=body; data.size=size
    data.align_x='CENTER'; data.align_y='CENTER'; data.extrude=.0003
    ob=c.link(bpy.data.objects.new(name,data)); ob.location=loc
    ob.rotation_euler=(math.pi/2,0,math.pi if back else 0); data.materials.append(c.M[material])
    return ob

def display_sign(key, number, x, y):
    c.box('Exhibition information card | '+key, (x,y,.98), (.76,.035,.29), 'plinth', .009)
    c.rod('Information stand | '+key, (x,y,.04), (x,y,.85), .012, 'brass')
    c.box('Information stand foot | '+key, (x,y,.014), (.29,.23,.028), 'brass', .012)
    text('Zone title | '+key, f'{number:02d} / '+zones[key]['label'], (x,y-.020,1.035), .039)
    text('Zone caption | '+key, 'SIENNA  /  WARM BROWN ASH', (x,y-.020,.94), .024)
    text('Zone title back | '+key, f'{number:02d} / '+zones[key]['label'], (x,y+.020,1.035), .039, back=True)
    text('Zone caption back | '+key, 'SIENNA  /  WARM BROWN ASH', (x,y+.020,.94), .024, back=True)
    colliders.append([x-.4,y-.14,x+.4,y+.14])

for key,number,x,y in [('master',1,.95,6.38),('guest',2,7,6.38),('living',3,.70,.45),('dining',4,7,.45)]:
    display_sign(key,number,x,y)

c.box('Gallery welcome card', (6,-.87,1.05), (1.65,.045,.64), 'plinth', .018)
for x in [5.42,6.58]:
    c.rod('Welcome sign freestanding leg', (x,-.87,.02), (x,-.87,.78), .016, 'brass')
    c.box('Welcome sign foot', (x,-.87,.015), (.30,.30,.03), 'brass', .01)
text('Welcome | SIENNA', 'S I E N N A', (6,-.896,1.17), .17)
text('Welcome | The Open Gallery', 'THE OPEN GALLERY / 2026', (6,-.896,.96), .052)
colliders.append([5.15,-1.04,6.85,-.70])

# Freestanding display lamps: no wall-mounted fittings or unsupported pendants.
for x,y,dx in [(-.8,10.8,1),(12.8,10.8,-1),(-.8,-.35,1),(12.8,-.35,-1)]:
    c.cylinder('Exhibition lamp base', (x,y,.022), .18,.044,'black')
    c.rod('Exhibition lamp upright', (x,y,.04),(x,y,3.2), .019,'black')
    c.rod('Exhibition lamp arm', (x,y,3.2),(x+dx*.7,y,3.2), .018,'black')
    c.cylinder('Exhibition spotlight', (x+dx*.7,y,3.14), .07,.14,'black')
    c.cylinder('Exhibition spotlight lens', (x+dx*.7,y,3.068), .055,.004,'light')
    colliders.append([x-.2,y-.2,x+.2,y+.2])

# Catalogue mirror stays in the collection, now supported by an exhibition stand.
for y in [7.03,7.71]:
    c.rod('Freestanding catalogue mirror support', (.12,y,.025),(.12,y,1.12), .011,'brass')
    c.rod('Catalogue mirror stabilising foot', (-.05,y,.02),(.43,y,.02), .013,'brass')

# Place the formerly wall-mounted television on its own cabinet.
for ob in scene.objects:
    if ob.name.startswith(('Thin framed television','TV dark glass screen')):
        ob.location.z-=.30
for x in [2.49,3.41]:
    c.rod('TV tabletop foot', (x,.15,.60),(x,.28,.555), .009,'black')

c.set_parent(None)
world = bpy.data.worlds.new('Open exhibition | warm studio environment'); world.use_nodes=True
world.node_tree.nodes.get('Background').inputs[0].default_value=(.69,.73,.77,1)
world.node_tree.nodes.get('Background').inputs[1].default_value=.48
scene.world=world
for name,loc,power,target,size in [
    ('Exhibition key softbox',(-3,-4,10),1800,(5,5,.4),7),
    ('Exhibition right fill',(15,5,9),1400,(7,5,.5),8),
    ('Exhibition back rim',(5,14,10),1800,(6,7,.3),7),
    ('King display softbox',(3,8,6),420,(3,8,0),4),
    ('Queen display softbox',(9,8,6),420,(9,8,0),4),
    ('Living display softbox',(3,2.4,6),420,(3,2.4,0),4),
    ('Dining display softbox',(9,2.4,6),420,(9,2.4,0),4),
]:
    lamp=c.light(name,'AREA',loc,power,(1,.91,.79),target,size)
    # Secondary display fills do not need separate shadow atlases. The three
    # primary studio softboxes retain full-quality shadows at UHD resolution.
    if 'display softbox' in name:lamp.data.use_shadow=False

cameras = {
    'master':((18,-12.5,15),(6,5.1,.45),35),
    'dining':((6.65,-.65,2.4),(9.1,2.6,.7),31),
    'living':((5.6,5.0,2.3),(2.7,2,.65),32),
    'guest':((12.5,5.8,2.45),(8.8,8.8,.7),35),
}
for name,(loc,target,lens) in cameras.items():
    camera=bpy.data.objects['Camera '+name]; camera.location=loc
    camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.lens=lens; camera.data.dof.use_dof=False
    camera.data.dof.focus_distance=(Vector(target)-camera.location).length

metadata=json.loads((BASE/'scene.json').read_text())
metadata.update({'layout':'exhibition','title':'SIENNA | The Open Gallery','walls':0,'roof':False,
                 'floorBounds':[-1.5,-1.2,13.5,11.8], 'colliders':colliders,
                 'overview':{'position':[18,15,12.5],'target':[6,.45,-5.1],'fov':35}})
metadata['rooms']['master']['name']='King suite display'
metadata['rooms']['guest']['name']='Queen & reading display'
metadata['rooms']['living']['name']='Living collection'
metadata['rooms']['dining']['name']='Dining collection'
metadata['rooms']['dining']['camera']=[[6.65,-.15,1.65],[9.1,2.65,.95],30]
metadata['rooms']['hall'].update({'name':'Open gallery aisle','bounds':[-1.5,-1.2,13.5,11.8],
                                'camera':[[6,5.25,1.65],[6,8.8,1.25],35]})
scene['layout']='exhibition'
scene['web_scene_info']=json.dumps(metadata)
scene['interpretation']='Open furniture exhibition, no walls or ceiling. Original catalogue products and dimensions are retained.'
scene['creator']='Muhammad Rizky'
scene['exhibition_removed_objects']=len(removed)
scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=True
scene.render.threads_mode='FIXED';scene.render.threads=6
scene.view_settings.exposure=.15
scene.eevee.taa_render_samples=64;scene.eevee.use_raytracing=True;scene.eevee.use_fast_gi=True
scene.eevee.shadow_ray_count=3;scene.eevee.shadow_step_count=8
presentation.organise()
scene.timeline_markers[0].name='Open gallery | overview'
for image in bpy.data.images:
    if image.source=='FILE' and not image.packed_file:image.pack()
assert not any(ob.get('kind') in {'wall','ceiling','windowglass'} for ob in scene.objects)
assert len([ob for ob in scene.objects if ob.get('kind')=='product'])==17
assert len([ob for ob in scene.objects if ob.get('kind')=='articulation'])==32
(BASE/'exhibition-scene.json').write_text(json.dumps(metadata,indent=2))
(BASE/'exhibition-build.json').write_text(json.dumps({'removed_objects':removed,'walls':0,'roof':False,'products':14,'placements':17,'articulations':32,'cameras':cameras},indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'sienna-exhibition.blend'))
print('SIENNA_EXHIBITION_BUILT',len(removed),'removed;',len(scene.objects),'retained/new objects',flush=True)
