"""Extract the user's exact SIENNA catalogue product photographs for reference.

This does not render, retouch or generate new product images. PDF image clips
exclude the catalogue labels, logos and finish swatches. Queen/King share the
single bed photograph supplied by the catalogue. Thumbnails are intentionally
labelled as catalogue references in the website, not as Blender render outputs.

Run using Blender's bundled Python, or a Python with PyMuPDF available.
"""

from pathlib import Path
import sys

WORKSPACE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(WORKSPACE / '.local' / 'catalogue-review' / 'packages'))
import pymupdf as fitz

SOURCE = WORKSPACE / 'SIENNA CATALOGUE 2026.pdf'
DESTINATION = WORKSPACE / 'sites' / 'sienna-house' / 'dist' / 'assets' / 'catalogue'
CONTACT = WORKSPACE / '.local' / 'catalogue-review' / 'sienna-product-contact.jpg'

# Crop coordinates were reviewed against the catalogue page's 1888x1334 display.
# They are converted to the PDF's own page coordinates before rendering.
PAGE_DISPLAY = (1888.0, 1334.0)
CROPS = {
    'LV463-B01': (2, (117, 36, 985, 539)),
    'LV463-B02': (2, (117, 36, 985, 539)),
    'LV463-B42': (2, (1143, 220, 1490, 530)),
    'LV463-B51': (2, (80, 729, 455, 1226)),
    'LV463-B61': (2, (548, 846, 1132, 1218)),
    'LV463-B71': (2, (1254, 765, 1618, 1203)),
    'LV463-D01': (4, (424, 45, 1353, 503)),
    'LV463-L21': (4, (121, 811, 756, 1216)),
    'LV463-D21': (4, (885, 814, 1572, 1195)),
    'LV446-L01': (5, (62, 162, 812, 500)),
    'LV446-L02': (5, (910, 151, 1601, 501)),
    'LV446-L11': (5, (31, 892, 429, 1232)),
    'LV446-L12': (5, (465, 870, 805, 1230)),
    'LV446-L31': (5, (832, 887, 1636, 1230)),
}


def extract():
    DESTINATION.mkdir(parents=True, exist_ok=True)
    source = fitz.open(SOURCE)
    sheet = fitz.open()
    contact = sheet.new_page(width=1200, height=1100)
    for index, (sku, (page_number, bounds)) in enumerate(CROPS.items()):
        page = source[page_number-1]
        clip = fitz.Rect(bounds)
        clip.x0 *= page.rect.width/PAGE_DISPLAY[0]
        clip.x1 *= page.rect.width/PAGE_DISPLAY[0]
        clip.y0 *= page.rect.height/PAGE_DISPLAY[1]
        clip.y1 *= page.rect.height/PAGE_DISPLAY[1]
        scale = min(780/clip.width, 560/clip.height)
        photo = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=clip,
                                alpha=False, colorspace=fitz.csRGB)
        # Standard format gives website product layouts consistent whitespace.
        thumbnail_document = fitz.open()
        canvas = thumbnail_document.new_page(width=800, height=600)
        x = (800-photo.width)/2
        y = (600-photo.height)/2
        canvas.insert_image(fitz.Rect(x, y, x+photo.width, y+photo.height),
                            stream=photo.tobytes('png'))
        output = DESTINATION / (sku+'.jpg')
        thumbnail = canvas.get_pixmap(alpha=False, colorspace=fitz.csRGB)
        output.write_bytes(thumbnail.tobytes('jpeg', jpg_quality=92))
        column, row = index % 4, index // 4
        left, top = column*300, row*275
        contact.insert_image(fitz.Rect(left+4, top+23, left+296, top+252),
                             filename=str(output), keep_proportion=True)
        contact.insert_text((left+10, top+18), sku+' / PDF p'+str(page_number),
                            fontsize=11)
        print(sku, '800x600', output.stat().st_size, str(output), flush=True)
        thumbnail_document.close()
    CONTACT.parent.mkdir(parents=True, exist_ok=True)
    contact.get_pixmap(alpha=False).save(CONTACT, jpg_quality=91)
    print('CONTACT', CONTACT, flush=True)
    print('EXTRACTED', len(CROPS), flush=True)
    sheet.close()
    source.close()


if __name__ == '__main__':
    extract()

